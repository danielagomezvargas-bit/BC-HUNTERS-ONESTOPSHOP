# Prompts para Claude Code — Business Case Simulator

Usa estos prompts en orden dentro de Claude Code (`claude` en la terminal).
Cada uno produce un PR listo para mergear a `main`.

---

## Cómo empezar

```bash
git clone https://github.com/danielagomezvargas-bit/Busseinesscase-hunters-monetizacion.git
cd Busseinesscase-hunters-monetizacion
claude
```

---

## PR 1 — Estructura base (ya generada aquí, solo copiar)

Copia los archivos del zip entregado a las rutas indicadas:

```
src/types/index.ts
src/data/constants.ts
src/utils/format.ts
src/hooks/useWizard.ts
src/components/ui/Stepper.tsx
src/components/ui/Topbar.tsx
src/components/ui/NavButtons.tsx
src/components/WizardShell.tsx
src/components/steps/Step1_Datos.tsx
src/components/steps/Step2_Producto.tsx
src/components/steps/Step3_Proveedores.tsx
src/app/simulator/page.tsx
```

Luego en Claude Code:
```
Agrega el font IBM Plex Sans al layout.tsx existente y verifica que /simulator funcione
```

---

## PR 2 — Step 4: Share de pagos

```
Lee los archivos existentes en src/components/steps/ y src/hooks/useWizard.ts.

Crea src/components/steps/Step4_Share.tsx con:
- Header de solución con banco del paso 3 (trae el nombre del proveedor del paso anterior en tiempo real)
- TPV mensual editable con formato MXN mexicano (comas y puntos)
- Tabla "Pagos de contado": columnas Tipo de pago | Share % | TPV calculado
  - Point: T. Débito, T. Crédito, AMEX, Internacional
  - Online Payments: T. Débito, T. Crédito, AMEX, Internacional, OXXO, Red PayCash, Dep. y Transf., AM & MP Crédito
- Tabla "Financiamiento": título "📅 Financiamiento", pregunta "¿Qué meses ofrece el Seller? ✦"
  - Botones 3x/6x/9x/12x/18x/24x para activar plazos
  - Share % editable por plazo
  - TPV calculado
- Espacio en blanco entre ambas tablas (no divisor con borde)
- Chip "Share de pagos: X% ✓" que valida que contado+MSI sumen 100%
- Cargador de simulador xlsx con zona drag&drop + botón "Cargar archivo"
- No deja avanzar si el share no suma 100% o si el TPV está vacío
- Título "Pagos de contado", subtítulo "¿Cómo es el comportamiento de pago?"
- Título MSI con subtítulo "El share de pagos debe sumar 100%"
- Usa los colores del archivo COLORS en constants.ts
- Conecta con useWizard (sharePT, shareOP, setSharePT, setShareOP)
```

---

## PR 3 — Step 5: Comisiones

```
Lee Step4_Share.tsx y useWizard.ts.

Crea src/components/steps/Step5_Comisiones.tsx con:

RESUMEN (arriba, justo después del header de solución):
- Tabla estilo Excel con columnas: vacío | label | Mensual | Anual | Δ
- Filas: "MP vs. [nombre banco]" con subfilas "Ahorro One-time" y "Ahorro MSI"
- Fila subtotal en negritas, con doble línea arriba/abajo, fondo verde/rojo solo en celdas de valor
- Las filas de detalle sin flechas, solo número bold en color
- El subtotal sí tiene flechas (▼ ▲) y fondo de color

TABLAS SIDE BY SIDE (con scroll horizontal y deslizador):
Tabla izquierda — "💳 Pagos de contado":
- Columnas: Tipo de pago | Tasa actual (editable, ámbar) | Tasa MP (editable, azul) | Comisión actual $ | Comisión MP $ | Diferencia $ | Delta %
- Sin columna Share (ya se capturó en paso 4)
- Sin fila "Mercado Pago" (ya no está en la lista)
- Tasa base de MSI NO editable — toma el valor de T. Crédito en tiempo real
- Total comisiones: solo muestra comisión actual $ y comisión MP $ (sin diferencia ni delta en esa fila)
- Fila "Ahorro / Inversión": se llama "Ahorro" si MP es más barata, "Inversión" si es más cara
  - Solo la CELDA del monto tiene fondo verde o rojo, no toda la fila

Tabla derecha — "📅 Meses sin intereses":
- Columnas: Plazo | Share | Tasa base actual (NO editable, trae TC en tiempo real) | Sobretasa actual (editable) | Tasa base MP (NO editable) | Sobretasa MP (editable) | Comisión actual $ | Comisión MP $ | Diferencia $ | Delta %
- Tasa total MSI = tasa base + sobretasa
- Fila "Ahorro / Inversión MSI" igual que contado

Barra de scroll con indicador visual de posición (💳 Contado ← → 📅 MSI)

Save bar debajo: Comisión actual / Con MP / Ahorro mensual / Ahorro anual

Usa colores: tasa actual = ámbar, tasa MP = azul, diferencia = gris #EAECF0, delta = verde #D6EDD9 solo en celdas highlight
```

---

## PR 4 — Step 6: Propuesta de valor

```
Crea src/components/steps/Step6_Propuesta.tsx con:

- Pregunta "¿Dónde va a incrementar la venta?" con botones Point | Online Payments | Ambos
- Para cada producto seleccionado, mostrar:
  - Header con nombre del solver (mismo que paso 3) y TPV
  - Chips horizontales con las palancas (importar PALANCAS_PT y PALANCAS_OP de constants.ts)
  - Al seleccionar un chip aparece una fila en la tabla de abajo:
    - Columnas: Palanca de valor | % a incrementar (editable) | Referencia de mercado (badge azul) | Impacto mensual $ | Impacto anual $
    - Si la palanca es "Otro", mostrar campo de texto libre
  - Barra de total al pie: TPV mensual | Incremento mensual estimado | Incremento anual estimado (verde)
```

---

## PR 5 — Benchmark DB

```
Crea src/app/benchmark/page.tsx y src/components/benchmark/BenchmarkDashboard.tsx con:

REGLA: Solo almacena sellers donde el hunter confirmó tener tasas REALES.

Tabs: Dashboard | Tasas benchmark | Lista | Registrar | Cargar ejercicio (IA)

Dashboard:
- Filtros: industria, producto, rango TPV (6 rangos: <1M, 1-5M, 5-10M, 10-20M, 20-40M, >40M), hunter, status
- KPIs en %: tasa de éxito, hunters activos, comisión TD promedio actual vs MP
- Gráfica de status (barras horizontales con %)
- Lista de hunters clicables (filtran la vista)
- Tabla de propuestas con status editable haciendo click en el badge (Por definir, En proceso, Presentado, Ganado ✓, Perdido ✗, En pausa)

Tasas benchmark:
- Tabla 1: promedio por industria (TD, TC, AMEX, Internacional) — con fila de promedio general arriba de cada industria
- Tabla 2: promedio por banco/proveedor con columnas contado (TD/TC/AMEX/Intl) + MSI hasta 24x (tasa total = base + sobretasa)

Cargar ejercicio (módulo IA):
- Textarea para pegar contenido del ejercicio de monetización
- Botón "Interpretar con IA" que llama a /api/interpret-exercise
- Muestra resultado parseado para revisión
- Botón "Confirmar y guardar" que pre-llena el formulario de registro

Persistencia: localStorage con key "bm_v4" (fallback a estado local si no disponible)

Usa los tipos de src/types/index.ts (BenchmarkRecord)
```

---

## PR 6 — API route para IA

```
Crea src/app/api/interpret-exercise/route.ts que:
- Recibe POST con { content: string }
- Llama a Anthropic claude-sonnet-4-20250514 con un prompt estructurado
- Extrae: seller, rfc, industria, producto, proveedor, tpv, ticket, tasas, tasas_mp, msi, msi_mp, hunter
- Devuelve JSON con los campos extraídos + notas_ia
- Maneja errores con status 400/500
- Usa process.env.ANTHROPIC_API_KEY
```

---

## Orden recomendado

```
Semana 1: PR 1 (copiar archivos) → PR 2 (Share) → PR 3 (Comisiones)
Semana 2: PR 4 (Propuesta) → PR 5 (Benchmark) → PR 6 (IA API)
```
